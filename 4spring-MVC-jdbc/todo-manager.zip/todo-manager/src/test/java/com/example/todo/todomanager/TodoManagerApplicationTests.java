package com.example.todo.todomanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodoManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
